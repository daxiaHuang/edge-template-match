/* norm.c */
void normalize_mean_dt(float *data, const float *ref, size_t size);
