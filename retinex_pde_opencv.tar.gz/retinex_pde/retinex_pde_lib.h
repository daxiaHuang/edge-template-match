/* retinex_pde_lib.c */
float *retinex_pde(float *data, size_t nx, size_t ny, float t);
